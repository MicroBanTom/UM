// Адрес вашего сервера UM API Portal (обязательно HTTPS), без слеша в конце.
window.UM_API_BASE = "https://YOUR-SERVER.example.com";
