import os, sqlite3, hashlib, secrets, hmac, base64, json, time
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

BASE = Path(__file__).resolve().parent
DB_PATH = os.getenv("UM_DB_PATH", str(BASE / "um.db"))
SECRET = os.getenv("UM_SECRET", "")
if len(SECRET) < 32:
    # Development fallback only. Set UM_SECRET to a long random value in production.
    SECRET = secrets.token_urlsafe(48)

app = FastAPI(title="UM API Portal", version="0.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://localhost", "capacitor://localhost", "http://localhost"],
    allow_methods=["*"], allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at INTEGER NOT NULL
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS api_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            label TEXT NOT NULL,
            key_hash TEXT UNIQUE NOT NULL,
            prefix TEXT NOT NULL,
            last4 TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            revoked INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )""")

@app.on_event("startup")
def startup():
    init_db()

def pw_hash(password: str, salt: Optional[bytes] = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    return base64.urlsafe_b64encode(salt + digest).decode()

def pw_verify(password: str, stored: str) -> bool:
    raw = base64.urlsafe_b64decode(stored.encode())
    salt, expected = raw[:16], raw[16:]
    actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    return hmac.compare_digest(actual, expected)

def make_token(user_id: int) -> str:
    payload = base64.urlsafe_b64encode(json.dumps({
        "sub": user_id, "exp": int(time.time()) + 60 * 60 * 24 * 7
    }, separators=(",", ":")).encode()).decode().rstrip("=")
    signature = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return payload + "." + signature

def get_user(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Требуется авторизация")
    token = authorization[7:]
    try:
        payload, signature = token.split(".", 1)
        expected = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected):
            raise ValueError()
        data = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
        if data["exp"] < int(time.time()):
            raise ValueError()
        with db() as con:
            user = con.execute("SELECT id,email FROM users WHERE id=?", (data["sub"],)).fetchone()
        if not user:
            raise ValueError()
        return dict(user)
    except Exception:
        raise HTTPException(401, "Недействительный или истёкший токен")

class AuthInput(BaseModel):
    email: str = Field(min_length=5, max_length=254)
    password: str = Field(min_length=10, max_length=128)

class KeyInput(BaseModel):
    label: str = Field(default="Мой ключ", min_length=1, max_length=48)

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "UM API Portal", "version": "0.2.0"}

@app.post("/api/auth/register")
def register(body: AuthInput):
    email = body.email.strip().lower()
    if "@" not in email or "." not in email.split("@")[-1]:
        raise HTTPException(400, "Укажите корректный email")
    with db() as con:
        try:
            cur = con.execute(
                "INSERT INTO users(email,password_hash,created_at) VALUES(?,?,?)",
                (email, pw_hash(body.password), int(time.time()))
            )
            user_id = cur.lastrowid
        except sqlite3.IntegrityError:
            raise HTTPException(409, "Аккаунт с таким email уже существует")
    return {"token": make_token(user_id), "email": email}

@app.post("/api/auth/login")
def login(body: AuthInput):
    email = body.email.strip().lower()
    with db() as con:
        user = con.execute("SELECT id,email,password_hash FROM users WHERE email=?", (email,)).fetchone()
    if not user or not pw_verify(body.password, user["password_hash"]):
        raise HTTPException(401, "Неверный email или пароль")
    return {"token": make_token(user["id"]), "email": user["email"]}

@app.get("/api/me")
def me(user=Depends(get_user)):
    return user

@app.get("/api/keys")
def list_keys(user=Depends(get_user)):
    with db() as con:
        rows = con.execute(
            "SELECT id,label,prefix,last4,created_at,revoked FROM api_keys WHERE user_id=? ORDER BY id DESC",
            (user["id"],)
        ).fetchall()
    return {"keys": [dict(r) for r in rows]}

@app.post("/api/keys")
def create_key(body: KeyInput, user=Depends(get_user)):
    raw_key = "um_live_" + secrets.token_urlsafe(32)
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    prefix = raw_key[:12]
    last4 = raw_key[-4:]
    with db() as con:
        cur = con.execute(
            "INSERT INTO api_keys(user_id,label,key_hash,prefix,last4,created_at) VALUES(?,?,?,?,?,?)",
            (user["id"], body.label.strip(), key_hash, prefix, last4, int(time.time()))
        )
        key_id = cur.lastrowid
    # The full secret is returned only once and is never stored in plaintext.
    return {"id": key_id, "label": body.label.strip(), "key": raw_key, "prefix": prefix, "last4": last4}

@app.delete("/api/keys/{key_id}")
def revoke_key(key_id: int, user=Depends(get_user)):
    with db() as con:
        cur = con.execute(
            "UPDATE api_keys SET revoked=1 WHERE id=? AND user_id=? AND revoked=0",
            (key_id, user["id"])
        )
    if cur.rowcount == 0:
        raise HTTPException(404, "Ключ не найден или уже отозван")
    return {"ok": True}

@app.post("/v1/chat/completions")
def chat_completions(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer um_live_"):
        raise HTTPException(401, "Укажите действительный UM API key")
    raw_key = authorization[7:]
    digest = hashlib.sha256(raw_key.encode()).hexdigest()
    with db() as con:
        row = con.execute("SELECT id,revoked FROM api_keys WHERE key_hash=?", (digest,)).fetchone()
    if not row or row["revoked"]:
        raise HTTPException(401, "API-ключ недействителен или отозван")
    # The API key infrastructure is real; inference is intentionally not faked.
    raise HTTPException(503, "UM Model Engine ещё не подключён. Ключ принят, но генерация пока недоступна.")

