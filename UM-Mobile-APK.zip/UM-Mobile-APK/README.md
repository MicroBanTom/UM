# UM API Portal — Android (APK)

Приложение — обёртка Capacitor вокруг веб-интерфейса из `www/`. Бэкенд (`server/`) остаётся на вашем сервере.

## 1. Сервер
Задеплойте `server/` (Dockerfile внутри) на хост с HTTPS и задайте `UM_SECRET` (32+ символов).
В `server/app.py` добавлен CORS для `https://localhost` (origin приложения).

## 2. Адрес сервера
Откройте `www/config.js` и впишите свой HTTPS-URL.

## 3. Сборка APK
**Вариант A (проще):** загрузите папку в GitHub-репозиторий → Actions → "Build APK" → Run workflow → скачайте артефакт `app-debug.apk`.
**Вариант Б (локально):** `./build.sh` (Node, JDK 17, Android SDK).

APK — debug-подпись: ставится на телефон напрямую («Установка из неизвестных источников»). Для Google Play нужна release-сборка с вашим keystore.
